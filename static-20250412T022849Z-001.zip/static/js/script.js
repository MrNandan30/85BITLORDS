  function showAddModal() {
    document.getElementById("addCategoryModal").style.display = "flex";
  }
  function closeAddModal() {
    document.getElementById("addCategoryModal").style.display = "none";
  }
  function submitNewCategory() {
    const category = document.getElementById("newCategoryInput").value;
    fetch('/add_category', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ category })
    }).then(() => location.reload());
  }
  function deleteCategory(name) {
    if (confirm(`Delete category '${name}' and all its bills?`)) {
      fetch(`/delete_category/${name}`, { method: 'POST' }).then(() => location.reload());
    }
  }
  function confirmDelete(billId) {
    if (confirm('Delete this bill?')) {
      fetch(`/delete_bill/${billId}`, { method: 'POST' }).then(() => location.reload());
    }
  }
  
  function openManualModal(filename, missingFields) {
    document.getElementById('manualFilename').value = filename;
  
    fetch('/manual_field_prompt', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ missing: missingFields })
    })
    .then(res => res.json())
    .then(data => {
      const suggestions = data.suggestions || {};
      const container = document.getElementById('manualFieldInputs');
      container.innerHTML = '';
  
      missingFields.forEach(field => {
        const wrapper = document.createElement('div');
        wrapper.innerHTML = `
          <label class="block text-sm font-medium text-gray-900 dark:text-white">${field}</label>
          <input name="${field}" list="suggest-${field}" placeholder="Enter ${field}" class="w-full p-2 border rounded dark:bg-gray-700 dark:text-white" />
          <datalist id="suggest-${field}">
            ${(suggestions[field] || []).map(val => `<option value="${val}">`).join('')}
          </datalist>
        `;
        container.appendChild(wrapper);
      });
  
      document.getElementById('manualFieldModal').classList.remove('hidden');
    });
  }
  
  function closeManualModal() {
    document.getElementById('manualFieldModal').classList.add('hidden');
  }
  
  // Submit manual fields
  document.getElementById('manualFieldForm').addEventListener('submit', function (e) {
    e.preventDefault();
  
    const filename = document.getElementById('manualFilename').value;
    const inputs = document.querySelectorAll('#manualFieldInputs input');
    const fields = {};
    inputs.forEach(input => {
      fields[input.name] = input.value;
    });
  
    fetch('/manual_field_submit', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ filename, fields })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        closeManualModal();
        alert("Info saved!");
        location.reload();  // optional: refresh to reflect DB update
      }
    });
  });
  



  
  
  
  